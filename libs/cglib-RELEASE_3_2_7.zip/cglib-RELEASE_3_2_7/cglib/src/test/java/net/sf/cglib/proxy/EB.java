package net.sf.cglib.proxy;

public class EB extends EA implements Comparable{
	private int count;

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}
        public final  void finalTest(){} 
}

